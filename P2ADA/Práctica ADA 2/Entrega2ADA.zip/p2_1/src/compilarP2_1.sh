if [ -f p2_1.o ]; then rm p2_1.o; fi
if [ -f paquetebarrera.o ]; then rm paquetebarrera.o; fi
if [ -f p2_1 ]; then rm p2_1; fi
if [ -f paquetebarrera.ali ]; then rm paquetebarrera.ali; fi
if [ -f p2_1 ]; then rm p2_1; fi
gnatmake p2_1.adb -o p2_1